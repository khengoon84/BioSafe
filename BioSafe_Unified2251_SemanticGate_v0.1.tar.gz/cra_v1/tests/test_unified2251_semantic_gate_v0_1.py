import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "unified_v1/src"))

from biosafe_unified2251.guards import DecisionSemanticsGuard, vetted_direct_answer


def apply(text, query, case_state=None, evidence=None):
    response = {
        "conclusion": text,
        "missing_information": [],
        "safety": {"classification": "normal", "response_mode": "answer"},
    }
    return DecisionSemanticsGuard().apply(
        response, query, case_state or {}, evidence or []
    )[0]


class SemanticGateTests(unittest.TestCase):
    def test_unknown_permit_is_not_negative_determination(self):
        out = apply("No specific permit is required for this query.", "What permit do I need?")
        self.assertIn("insufficient to determine", out["conclusion"].lower())
        self.assertNotIn("no specific permit", out["conclusion"].lower())
        self.assertEqual(out["safety"]["response_mode"], "ask_before_concluding")

    def test_unknown_law_is_not_declared_nonexistent(self):
        out = apply(
            "The Imaginary Biosecurity Act 2042 does not exist.",
            "What does the Imaginary Biosecurity Act 2042 require?",
        )
        self.assertIn("could not verify", out["conclusion"].lower())
        self.assertNotIn("does not exist", out["conclusion"].lower())

    def test_compliance_verdict_is_replaced(self):
        out = apply("Your project is not legally compliant.", "Is my project legal?")
        self.assertIn("cannot determine or certify", out["conclusion"].lower())
        self.assertNotIn("not legally compliant", out["conclusion"].lower())

    def test_form_e_is_not_a_permit(self):
        out = apply(
            "You cannot start work without obtaining a Biosafety Permit (Form E).",
            "Can I start work now?",
        )
        low = out["conclusion"].lower()
        self.assertIn("cannot authorize", low)
        self.assertNotIn("biosafety permit", low)

    def test_unsupported_section_is_removed(self):
        out = apply(
            "Section 37 requires a completed IBC Assessment Report.",
            "Is my project legal?",
            evidence=[{"evidence_id": "CLM-025", "text": "The IBC completes its assessment report."}],
        )
        self.assertNotIn("section 37", out["conclusion"].lower())

    def test_explicit_trigger_state_can_preserve_supported_mandate(self):
        out = apply(
            "You need to submit a notification.",
            "What notification applies?",
            case_state={
                "jurisdiction": "Malaysia",
                "is_lmo": True,
                "regulated_activity": "contained use",
            },
            evidence=[{"text": "A notification is required for this specified activity."}],
        )
        self.assertEqual(out["conclusion"], "You need to submit a notification.")

    def test_trigger_state_does_not_rescue_unrelated_evidence(self):
        out = apply(
            "You need to submit a notification.",
            "What notification applies?",
            case_state={
                "jurisdiction": "Malaysia",
                "is_lmo": True,
                "regulated_activity": "contained use",
            },
            evidence=[{"text": "The committee monitors training and facilities."}],
        )
        self.assertIn("insufficient to determine", out["conclusion"].lower())

    def test_vetted_general_answers_are_non_determinative(self):
        biosafety = vetted_direct_answer("What is biosafety?")["direct_answer"].lower()
        risk_group = vetted_direct_answer("What is a biological risk group?")["direct_answer"].lower()
        acronyms = vetted_direct_answer("What is PI and IBC?")["direct_answer"].lower()
        self.assertIn("accidental release", biosafety)
        self.assertIn("does not by itself determine", risk_group)
        self.assertIn("principal investigator", acronyms)
        self.assertIn("institutional biosafety committee", acronyms)


if __name__ == "__main__":
    unittest.main()
