from pathlib import Path
import sys

ROOT = Path("/home/khengoon/biosafe")
for path in (ROOT / "src", ROOT / "unified_v1/src"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

import full_inference_service_v0_1 as frozen
from biosafe_unified221 import EvidenceRequirementPlanner
from biosafe_unified22 import load_constitution, augment_compact_messages
from biosafe_unified222 import normalize_intent
from biosafe_unified223 import ScopedPipelineAdapter
from biosafe_unified224 import ResponseTypeContractEnforcer
from biosafe_unified2241 import EvidencePreservingSemanticVerifier
from biosafe_unified2242 import SubjectAwareEvidenceScopeEnforcer
from biosafe_unified225 import RequestedSubjectCoverageGuard, SafetyRationaleGuard
from biosafe_unified2251.guards import DecisionSemanticsGuard, vetted_direct_answer


class Unified2251Service:
    def __init__(self):
        self.planner = EvidenceRequirementPlanner()
        self.scope = SubjectAwareEvidenceScopeEnforcer()
        self.constitution = load_constitution()
        self.engine = frozen.BioSafeFullInferenceServiceV011(ROOT)
        self.contract = ResponseTypeContractEnforcer()
        self.semantic = EvidencePreservingSemanticVerifier()
        self.decision = DecisionSemanticsGuard()
        self.coverage = RequestedSubjectCoverageGuard()
        self.safety_rationale = SafetyRationaleGuard()

    def intent(self, prep):
        return normalize_intent(prep["query"], prep.get("intent"))

    def plan(self, prep):
        intent = self.intent(prep)
        if intent == "self_knowledge":
            intent = "simple_answer"
        return self.planner.plan(
            intent,
            prep["query"],
            attachments_present=bool(prep.get("attachments")),
            case_state=prep.get("case_state") or {},
        )

    def direct(self, prep, intent):
        if intent == "product_help":
            return {
                "direct_answer": (
                    "I’m BioSafe, an evidence-grounded biosafety and biosecurity assistant for "
                    "researchers. I can explain biosafety concepts, help assess regulatory questions, "
                    "review biosafety-related documents, and assist with researcher-facing Form E preparation."
                ),
                "limitations": [
                    "I provide decision support and do not grant regulatory approval or certify compliance."
                ],
            }
        if intent == "self_knowledge":
            return {
                "direct_answer": (
                    "I only know information you’ve shared with me in this BioSafe conversation or "
                    "project context. I don’t independently know your identity."
                )
            }
        return vetted_direct_answer(prep["query"])

    def infer(self, prep, documents=None):
        documents = documents or []
        intent = self.intent(prep)
        plan = self.plan(prep)
        direct = self.direct(prep, intent)
        if direct is not None:
            direct["_normalized_intent"] = intent
            direct["_evidence_plan"] = plan.__dict__
            return direct

        original_pipeline = self.engine.pipeline
        original_compact = frozen._compact_messages
        scoped = ScopedPipelineAdapter(original_pipeline, self.scope, plan, prep["query"])
        captured = {"evidence": []}

        def compact(base, query, bundle, packet, policy, profile, workflow):
            captured["evidence"] = [dict(item) for item in bundle.get("evidence_bundle", [])]
            messages = original_compact(base, query, bundle, packet, policy, profile, workflow)
            return augment_compact_messages(
                messages,
                constitution=self.constitution,
                interaction_context={
                    "intent": intent,
                    "case_state": prep.get("case_state") or {},
                    "resolved_reference": prep.get("resolved_reference"),
                    "attachments_present": bool(prep.get("attachments")),
                    "evidence_plan": plan.__dict__,
                },
            )

        self.engine.pipeline = scoped
        frozen._compact_messages = compact
        try:
            out = self.engine.infer(
                prep["query"],
                documents=documents,
                workflow={"review": "document_review", "form-e": "form_e"}.get(
                    prep["workflow"], "ask"
                ),
            )
        finally:
            self.engine.pipeline = original_pipeline
            frozen._compact_messages = original_compact

        out, semantic_audit = self.semantic.apply(out, captured["evidence"])
        out, decision_audit = self.decision.apply(
            out, prep["query"], prep.get("case_state") or {}, captured["evidence"]
        )
        out, coverage_audit = self.coverage.apply(out, prep["query"], captured["evidence"])
        out, safety_audit = self.safety_rationale.apply(out, prep["query"])
        out, contract_audit = self.contract.apply(out, intent)
        out["_normalized_intent"] = intent
        out["_evidence_plan"] = plan.__dict__
        out["_scope_audit"] = scoped.audit
        out["_semantic_verifier"] = {
            "audit": semantic_audit,
            "scoped_evidence_ids": [item.get("evidence_id") for item in captured["evidence"]],
        }
        out["_decision_semantics"] = {"audit": decision_audit}
        out["_subject_coverage"] = {"audit": coverage_audit}
        out["_safety_rationale"] = {"audit": safety_audit}
        out["_response_contract"] = {"intent": intent, "audit": contract_audit}
        return out
